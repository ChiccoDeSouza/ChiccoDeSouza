# Instruções de Deploy - Cosmetic Factory

Este documento contém instruções detalhadas para o deploy do sistema Cosmetic Factory em ambiente de produção.

## Requisitos de Sistema

- Ruby 3.2.0 ou superior
- Rails 7.1.0 ou superior
- PostgreSQL 14.0 ou superior
- Redis 5.0 ou superior
- Node.js 16.0 ou superior
- Yarn 1.22 ou superior

## Configuração do Ambiente

### 1. Configuração de Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:

```
# Database
DB_USERNAME=seu_usuario_postgres
DB_PASSWORD=sua_senha_postgres
DB_HOST=seu_host_postgres
DB_PORT=5432

# Redis
REDIS_URL=redis://localhost:6379/1

# Secrets
RAILS_MASTER_KEY=chave_mestra_rails
DEVISE_SECRET_KEY=chave_secreta_devise

# SMTP (para envio de emails)
SMTP_ADDRESS=smtp.exemplo.com
SMTP_PORT=587
SMTP_DOMAIN=exemplo.com
SMTP_USERNAME=seu_usuario
SMTP_PASSWORD=sua_senha
SMTP_AUTHENTICATION=plain
SMTP_ENABLE_STARTTLS_AUTO=true

# AWS S3 (para armazenamento de arquivos)
AWS_ACCESS_KEY_ID=sua_chave_aws
AWS_SECRET_ACCESS_KEY=seu_segredo_aws
AWS_REGION=sua_regiao_aws
AWS_BUCKET=seu_bucket_aws
```

### 2. Instalação de Dependências

```bash
# Instalar dependências Ruby
bundle install --without development test

# Instalar dependências JavaScript
yarn install
```

### 3. Compilação de Assets

```bash
# Compilar JavaScript e CSS
rails assets:precompile
```

### 4. Configuração do Banco de Dados

```bash
# Criar banco de dados
rails db:create RAILS_ENV=production

# Executar migrações
rails db:migrate RAILS_ENV=production

# Carregar dados iniciais (opcional)
rails db:seed RAILS_ENV=production
```

## Deploy em Servidor Próprio

### 1. Configuração do Servidor Web (Nginx)

Crie um arquivo de configuração para o Nginx:

```nginx
upstream cosmetic_factory {
  server unix:///var/www/cosmetic_factory/shared/tmp/sockets/puma.sock;
}

server {
  listen 80;
  server_name seu_dominio.com;

  root /var/www/cosmetic_factory/current/public;

  location ^~ /assets/ {
    gzip_static on;
    expires max;
    add_header Cache-Control public;
  }

  location ^~ /packs/ {
    gzip_static on;
    expires max;
    add_header Cache-Control public;
  }

  try_files $uri/index.html $uri @cosmetic_factory;
  
  location @cosmetic_factory {
    proxy_pass http://cosmetic_factory;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Ssl on;
    proxy_set_header X-Forwarded-Port $server_port;
    proxy_set_header X-Forwarded-Host $host;
  }

  error_page 500 502 503 504 /500.html;
  client_max_body_size 10M;
  keepalive_timeout 10;
}
```

### 2. Configuração do Puma (Servidor de Aplicação)

Crie um arquivo `config/puma.rb`:

```ruby
# Puma pode servir cada requisição em uma thread de um pool de threads.
# O valor padrão é 5 threads para requisições mínimas e máximas.
max_threads_count = ENV.fetch("RAILS_MAX_THREADS") { 5 }
min_threads_count = ENV.fetch("RAILS_MIN_THREADS") { max_threads_count }
threads min_threads_count, max_threads_count

# Especifica a porta em que o servidor Puma irá escutar
port ENV.fetch("PORT") { 3000 }

# Especifica o ambiente em que o rack irá rodar
environment ENV.fetch("RAILS_ENV") { "development" }

# Especifica o número de processos a serem gerados
workers ENV.fetch("WEB_CONCURRENCY") { 2 }

# Use o plugin de preload para reduzir o uso de memória
preload_app!

# Diretório onde o servidor irá armazenar os arquivos temporários
directory ENV.fetch("RAILS_ROOT") { "." }

# Socket para comunicação com o servidor web
bind "unix://#{ENV.fetch("RAILS_ROOT") { "." }}/tmp/sockets/puma.sock"

# Arquivo de estado do servidor
state_path "#{ENV.fetch("RAILS_ROOT") { "." }}/tmp/pids/puma.state"

# Arquivo de pid do servidor
pidfile "#{ENV.fetch("RAILS_ROOT") { "." }}/tmp/pids/puma.pid"

# Arquivo de log do servidor
stdout_redirect "#{ENV.fetch("RAILS_ROOT") { "." }}/log/puma.stdout.log", 
                "#{ENV.fetch("RAILS_ROOT") { "." }}/log/puma.stderr.log", 
                true

# Permite que o Puma seja reiniciado por um arquivo ou sinal
plugin :tmp_restart
```

### 3. Configuração do Sidekiq (Processamento em Background)

Crie um arquivo `config/sidekiq.yml`:

```yaml
:concurrency: 5
:queues:
  - default
  - mailers
  - active_storage_analysis
  - active_storage_purge
```

### 4. Configuração do Systemd para Serviços

#### Puma Service

Crie um arquivo `/etc/systemd/system/cosmetic_factory_puma.service`:

```ini
[Unit]
Description=Cosmetic Factory Puma Server
After=network.target

[Service]
Type=simple
User=deploy
WorkingDirectory=/var/www/cosmetic_factory/current
Environment=RAILS_ENV=production
ExecStart=/home/deploy/.rbenv/shims/bundle exec puma -C config/puma.rb
ExecStop=/home/deploy/.rbenv/shims/bundle exec pumactl -S /var/www/cosmetic_factory/current/tmp/pids/puma.state stop
TimeoutSec=15
Restart=always

[Install]
WantedBy=multi-user.target
```

#### Sidekiq Service

Crie um arquivo `/etc/systemd/system/cosmetic_factory_sidekiq.service`:

```ini
[Unit]
Description=Cosmetic Factory Sidekiq Worker
After=network.target

[Service]
Type=simple
User=deploy
WorkingDirectory=/var/www/cosmetic_factory/current
Environment=RAILS_ENV=production
ExecStart=/home/deploy/.rbenv/shims/bundle exec sidekiq -e production -C config/sidekiq.yml
ExecStop=/usr/bin/pkill -f sidekiq
TimeoutSec=15
Restart=always

[Install]
WantedBy=multi-user.target
```

### 5. Iniciar os Serviços

```bash
# Recarregar configurações do systemd
sudo systemctl daemon-reload

# Iniciar e habilitar os serviços
sudo systemctl start cosmetic_factory_puma
sudo systemctl enable cosmetic_factory_puma
sudo systemctl start cosmetic_factory_sidekiq
sudo systemctl enable cosmetic_factory_sidekiq
```

## Deploy com Capistrano (Recomendado)

Para automatizar o processo de deploy, recomendamos o uso do Capistrano.

### 1. Configuração do Capistrano

Adicione ao Gemfile:

```ruby
group :development do
  gem 'capistrano', '~> 3.17'
  gem 'capistrano-rails', '~> 1.6'
  gem 'capistrano-rbenv', '~> 2.2'
  gem 'capistrano3-puma', '~> 5.2'
  gem 'capistrano-sidekiq', '~> 2.0'
end
```

Execute:

```bash
bundle install
cap install
```

### 2. Configuração dos Arquivos do Capistrano

#### config/deploy.rb

```ruby
# config valid for current version and patch releases of Capistrano
lock "~> 3.17.0"

set :application, "cosmetic_factory"
set :repo_url, "git@github.com:seu-usuario/cosmetic_factory.git"

# Configurações de deploy
set :deploy_to, "/var/www/#{fetch(:application)}"
set :branch, 'main'

# Configurações do rbenv
set :rbenv_type, :user
set :rbenv_ruby, '3.2.0'
set :rbenv_prefix, "RBENV_ROOT=#{fetch(:rbenv_path)} RBENV_VERSION=#{fetch(:rbenv_ruby)} #{fetch(:rbenv_path)}/bin/rbenv exec"
set :rbenv_map_bins, %w{rake gem bundle ruby rails puma pumactl sidekiq sidekiqctl}

# Configurações do Puma
set :puma_threads, [4, 16]
set :puma_workers, 0
set :puma_bind, "unix://#{shared_path}/tmp/sockets/puma.sock"
set :puma_state, "#{shared_path}/tmp/pids/puma.state"
set :puma_pid, "#{shared_path}/tmp/pids/puma.pid"
set :puma_access_log, "#{release_path}/log/puma.access.log"
set :puma_error_log, "#{release_path}/log/puma.error.log"
set :puma_preload_app, true
set :puma_worker_timeout, nil
set :puma_init_active_record, true

# Configurações do Sidekiq
set :sidekiq_config, "config/sidekiq.yml"
set :sidekiq_env, fetch(:rack_env, fetch(:rails_env, 'production'))

# Arquivos compartilhados
append :linked_files, ".env", "config/master.key"
append :linked_dirs, "log", "tmp/pids", "tmp/cache", "tmp/sockets", "public/system", "public/uploads", "storage"

# Tarefas de deploy
namespace :deploy do
  desc 'Reiniciar aplicação'
  task :restart do
    on roles(:app), in: :sequence, wait: 5 do
      invoke 'puma:restart'
      invoke 'sidekiq:restart'
    end
  end

  after :publishing, :restart
end
```

#### config/deploy/production.rb

```ruby
server "seu_servidor.com", user: "deploy", roles: %w{app db web}
```

### 3. Executar o Deploy

```bash
# Configurar o servidor (primeira vez)
cap production deploy:check

# Fazer o deploy
cap production deploy
```

## Deploy em Plataformas como Serviço

### Heroku

1. Instale o Heroku CLI e faça login:

```bash
heroku login
```

2. Crie um novo aplicativo:

```bash
heroku create cosmetic-factory
```

3. Adicione os add-ons necessários:

```bash
heroku addons:create heroku-postgresql:hobby-dev
heroku addons:create heroku-redis:hobby-dev
heroku addons:create scheduler:standard
```

4. Configure as variáveis de ambiente:

```bash
heroku config:set RAILS_MASTER_KEY=$(cat config/master.key)
heroku config:set RAILS_ENV=production
heroku config:set RACK_ENV=production
```

5. Faça o deploy:

```bash
git push heroku main
```

6. Execute as migrações:

```bash
heroku run rails db:migrate
```

7. Configure o worker do Sidekiq:

```bash
heroku ps:scale web=1 worker=1
```

## Monitoramento e Manutenção

### Monitoramento

- Configure o Sentry para monitoramento de erros
- Use o Prometheus para métricas de desempenho
- Configure alertas para problemas críticos

### Backups

Configure backups regulares do banco de dados:

```bash
# Exemplo de script de backup para PostgreSQL
pg_dump -U $DB_USERNAME -h $DB_HOST $DB_NAME > backup_$(date +%Y%m%d).sql
```

### Atualizações de Segurança

Mantenha o sistema atualizado com as últimas correções de segurança:

```bash
# Verificar atualizações de segurança
bundle audit check --update

# Verificar vulnerabilidades no código
brakeman
```

## Considerações de Segurança

1. **Sempre use HTTPS** em produção
2. Configure corretamente os cabeçalhos de segurança HTTP
3. Mantenha todas as dependências atualizadas
4. Realize auditorias de segurança regularmente
5. Implemente autenticação de dois fatores para usuários administrativos
6. Monitore tentativas de login suspeitas
7. Faça backups regulares e teste a restauração

## Troubleshooting

### Problemas Comuns e Soluções

1. **Erro 500 após deploy**
   - Verifique os logs: `tail -f log/production.log`
   - Verifique se todas as migrações foram executadas
   - Verifique se as variáveis de ambiente estão configuradas corretamente

2. **Problemas com assets**
   - Recompile os assets: `rails assets:precompile RAILS_ENV=production`
   - Verifique se o Nginx está configurado para servir os assets estáticos

3. **Sidekiq não está processando jobs**
   - Verifique se o serviço está rodando: `systemctl status cosmetic_factory_sidekiq`
   - Verifique a conexão com o Redis: `redis-cli ping`
   - Verifique os logs do Sidekiq: `tail -f log/sidekiq.log`

## Suporte

Para suporte adicional, entre em contato com a equipe de desenvolvimento.
