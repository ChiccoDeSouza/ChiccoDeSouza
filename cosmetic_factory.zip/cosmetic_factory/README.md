# README.md - Cosmetic Factory

Sistema de gestão para fábrica de cosméticos desenvolvido em Ruby on Rails.

## Visão Geral

O Cosmetic Factory é um sistema completo para gestão de fábricas de cosméticos, focado na administração de representantes comerciais, produtos, pedidos e clientes. O sistema foi desenvolvido utilizando Ruby on Rails 7.1, PostgreSQL, Hotwire (Turbo e Stimulus) e Tailwind CSS.

## Principais Funcionalidades

- **Gestão de Representantes**: Cadastro, gerenciamento e acompanhamento de desempenho
- **Catálogo de Produtos**: Gerenciamento completo de produtos e categorias
- **Controle de Estoque**: Monitoramento de níveis de estoque com alertas automáticos
- **Gestão de Pedidos**: Fluxo completo desde a criação até a entrega
- **Área de Representantes**: Interface dedicada para representantes gerenciarem seus clientes e pedidos
- **Relatórios Gerenciais**: Dashboards e relatórios para tomada de decisão
- **Conformidade LGPD**: Criptografia de dados sensíveis e ferramentas para exercício de direitos do titular

## Tecnologias Utilizadas

- **Backend**: Ruby 3.2.0, Rails 7.1.0
- **Banco de Dados**: PostgreSQL
- **Frontend**: Hotwire (Turbo e Stimulus), Tailwind CSS
- **Autenticação**: Devise
- **Autorização**: Pundit
- **Background Jobs**: Sidekiq
- **Segurança**: Rack Attack, Lockbox para criptografia
- **Monitoramento**: Sentry, Lograge

## Estrutura do Projeto

O projeto segue a arquitetura MVC do Rails com algumas adições:

- `app/models`: Modelos de dados e lógica de negócio
- `app/controllers`: Controllers divididos em namespaces (admin, representative, api)
- `app/views`: Views organizadas por namespace e funcionalidade
- `app/services`: Serviços para encapsular lógica de negócio complexa
- `app/policies`: Políticas de autorização usando Pundit
- `app/jobs`: Jobs em background processados pelo Sidekiq
- `app/mailers`: Classes para envio de emails
- `config`: Configurações da aplicação
- `db`: Migrações e seeds

## Requisitos de Sistema

- Ruby 3.2.0 ou superior
- Rails 7.1.0 ou superior
- PostgreSQL 14.0 ou superior
- Redis 5.0 ou superior (para Sidekiq)
- Node.js 16.0 ou superior
- Yarn 1.22 ou superior

## Instalação e Configuração

### Configuração do Ambiente de Desenvolvimento

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/cosmetic_factory.git
cd cosmetic_factory
```

2. Instale as dependências:
```bash
bundle install
yarn install
```

3. Configure o banco de dados:
```bash
cp config/database.yml.example config/database.yml
# Edite o arquivo database.yml com suas configurações locais
```

4. Configure as variáveis de ambiente:
```bash
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

5. Crie e migre o banco de dados:
```bash
rails db:create
rails db:migrate
rails db:seed
```

6. Inicie o servidor:
```bash
./bin/dev
```

7. Acesse a aplicação em `http://localhost:3000`

### Usuários Padrão

Após executar o seed, os seguintes usuários estarão disponíveis:

- **Administrador**:
  - Email: admin@cosmeticfactory.com
  - Senha: password123

- **Representante**:
  - Email: joao@cosmeticfactory.com
  - Senha: password123

## Deploy

Para instruções detalhadas de deploy, consulte o arquivo [DEPLOY.md](DEPLOY.md).

## Segurança

O sistema implementa diversas medidas de segurança:

- Autenticação robusta com Devise
- Autorização granular com Pundit
- Proteção contra ataques de força bruta com Rack Attack
- Criptografia de dados sensíveis com Lockbox
- Políticas de segurança de conteúdo (CSP)
- Proteção contra CSRF, XSS e SQL Injection

## Manutenção e Suporte

### Atualizações de Segurança

Recomendamos manter o sistema atualizado com as últimas correções de segurança:

```bash
bundle update --patch
bundle audit check --update
```

### Backups

Configure backups regulares do banco de dados conforme detalhado no arquivo DEPLOY.md.

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.

## Contato

Para suporte ou dúvidas, entre em contato com a equipe de desenvolvimento.
