# config/initializers/rack_attack.rb
class Rack::Attack
  # Limitar tentativas de login
  throttle('req/ip/login', limit: 10, period: 5.minutes) do |req|
    if req.path == '/users/sign_in' && req.post?
      req.ip
    end
  end

  # Limitar tentativas de recuperação de senha
  throttle('req/ip/password_reset', limit: 5, period: 15.minutes) do |req|
    if req.path == '/users/password' && req.post?
      req.ip
    end
  end

  # Limitar requisições gerais por IP
  throttle('req/ip', limit: 300, period: 5.minutes) do |req|
    req.ip unless req.path.start_with?('/assets')
  end

  # Bloquear IPs suspeitos
  blocklist('block suspicious IPs') do |req|
    Rack::Attack::Fail2Ban.filter("pentest-#{req.ip}", maxretry: 3, findtime: 10.minutes, bantime: 1.hour) do
      # Bloquear tentativas de acessar arquivos sensíveis
      req.path.include?('/etc/passwd') ||
      req.path.include?('wp-admin') ||
      req.path.include?('.git')
    end
  end

  # Configuração para ambiente de desenvolvimento
  Rack::Attack.enabled = Rails.env.production?
end
