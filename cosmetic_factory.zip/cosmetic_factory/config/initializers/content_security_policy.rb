# config/initializers/content_security_policy.rb
# Define uma política de segurança de conteúdo para proteger contra ataques XSS
Rails.application.config.content_security_policy do |policy|
  policy.default_src :self, :https
  policy.font_src    :self, :https, :data
  policy.img_src     :self, :https, :data
  policy.object_src  :none
  policy.script_src  :self, :https
  policy.style_src   :self, :https
  
  # Permitir conexões WebSocket em desenvolvimento
  policy.connect_src :self, :https, "http://localhost:3035", "ws://localhost:3035" if Rails.env.development?

  # Gerar nonces para scripts inline permitidos
  policy.script_src :self, :https, :unsafe_inline

  # Habilitar o modo de relatório, que envia violações para o endpoint especificado
  # policy.report_uri "/csp-violation-report-endpoint"
end

# Gerar nonces para cada solicitação para scripts inline
Rails.application.config.content_security_policy_nonce_generator = -> request { SecureRandom.base64(16) }

# Definir nonce automaticamente para scripts e estilos
Rails.application.config.content_security_policy_nonce_directives = %w(script-src style-src)

# Relatar violações de CSP sem bloquear conteúdo violador
# Rails.application.config.content_security_policy_report_only = true
