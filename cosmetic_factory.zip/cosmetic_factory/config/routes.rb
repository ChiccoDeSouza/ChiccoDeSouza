# config/routes.rb
Rails.application.routes.draw do
  # Autenticação
  devise_for :users, controllers: {
    sessions: 'users/sessions',
    registrations: 'users/registrations',
    passwords: 'users/passwords'
  }
  
  # Sidekiq Web UI (apenas para admins)
  authenticate :user, ->(user) { user.admin? } do
    require 'sidekiq/web'
    mount Sidekiq::Web => '/sidekiq'
  end
  
  # Área pública
  root to: 'home#index'
  
  # Área de representantes
  namespace :representative do
    get '/', to: 'dashboard#index', as: :root
    resources :dashboard, only: [:index]
    resources :products, only: [:index, :show]
    resources :customers
    resources :orders do
      member do
        patch :cancel
      end
    end
  end
  
  # Área administrativa
  namespace :admin do
    get '/', to: 'dashboard#index', as: :root
    resources :dashboard, only: [:index]
    resources :representatives
    resources :products do
      collection do
        get :inactive
      end
    end
    resources :categories
    resources :customers do
      collection do
        get :inactive
      end
    end
    resources :orders do
      member do
        patch :update_status
      end
    end
    resources :stock_items do
      collection do
        get :low_stock
      end
    end
    resources :reports, only: [:index] do
      collection do
        get :sales
        get :inventory
        get :representatives_performance
      end
    end
  end
  
  # API para LGPD
  namespace :api do
    namespace :v1 do
      resources :data_rights, only: [:show, :destroy] do
        collection do
          get :export
        end
      end
    end
  end
end
