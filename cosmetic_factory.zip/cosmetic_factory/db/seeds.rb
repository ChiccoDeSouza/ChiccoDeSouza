# db/seeds.rb
# Este arquivo contém os dados iniciais para o sistema

# Limpar dados existentes
puts "Limpando dados existentes..."
OrderItem.destroy_all
Order.destroy_all
StockItem.destroy_all
Product.destroy_all
Category.destroy_all
Customer.destroy_all
User.destroy_all

# Criar administrador
puts "Criando administrador..."
admin = User.create!(
  name: "Administrador",
  email: "admin@cosmeticfactory.com",
  password: "password123",
  role: :admin,
  active: true
)

# Criar representantes
puts "Criando representantes..."
representantes = [
  {
    name: "João Silva",
    email: "joao@cosmeticfactory.com",
    password: "password123",
    margin_percentage: 15.0,
    region: "Sul",
    commission_rate: 5.0,
    phone: "(48) 99999-1111",
    document: "111.222.333-44"
  },
  {
    name: "Maria Oliveira",
    email: "maria@cosmeticfactory.com",
    password: "password123",
    margin_percentage: 18.0,
    region: "Sudeste",
    commission_rate: 6.0,
    phone: "(11) 99999-2222",
    document: "222.333.444-55"
  },
  {
    name: "Carlos Santos",
    email: "carlos@cosmeticfactory.com",
    password: "password123",
    margin_percentage: 20.0,
    region: "Nordeste",
    commission_rate: 7.0,
    phone: "(81) 99999-3333",
    document: "333.444.555-66"
  }
]

created_representatives = representantes.map do |rep_data|
  Representative.create!(rep_data.merge(active: true))
end

# Criar categorias
puts "Criando categorias..."
categorias = [
  { name: "Cuidados Faciais", description: "Produtos para cuidados com a pele do rosto" },
  { name: "Cuidados Corporais", description: "Produtos para cuidados com a pele do corpo" },
  { name: "Cabelos", description: "Produtos para cuidados com os cabelos" },
  { name: "Maquiagem", description: "Produtos de maquiagem" },
  { name: "Perfumaria", description: "Perfumes e fragrâncias" }
]

created_categories = categorias.map do |cat_data|
  Category.create!(cat_data.merge(active: true))
end

# Criar produtos
puts "Criando produtos..."
produtos = [
  {
    name: "Creme Facial Hidratante",
    description: "Creme hidratante para todos os tipos de pele",
    base_price: 45.90,
    sku: "CF001",
    category: created_categories[0]
  },
  {
    name: "Protetor Solar FPS 50",
    description: "Protetor solar de alta proteção para rosto",
    base_price: 59.90,
    sku: "CF002",
    category: created_categories[0]
  },
  {
    name: "Sérum Anti-idade",
    description: "Sérum concentrado para combater sinais de envelhecimento",
    base_price: 89.90,
    sku: "CF003",
    category: created_categories[0]
  },
  {
    name: "Loção Corporal Hidratante",
    description: "Loção hidratante para pele seca",
    base_price: 39.90,
    sku: "CF004",
    category: created_categories[1]
  },
  {
    name: "Esfoliante Corporal",
    description: "Esfoliante para renovação celular",
    base_price: 49.90,
    sku: "CF005",
    category: created_categories[1]
  },
  {
    name: "Shampoo Nutritivo",
    description: "Shampoo para cabelos danificados",
    base_price: 35.90,
    sku: "CF006",
    category: created_categories[2]
  },
  {
    name: "Condicionador Reparador",
    description: "Condicionador para cabelos danificados",
    base_price: 38.90,
    sku: "CF007",
    category: created_categories[2]
  },
  {
    name: "Máscara Capilar",
    description: "Máscara de tratamento intensivo",
    base_price: 45.90,
    sku: "CF008",
    category: created_categories[2]
  },
  {
    name: "Base Líquida",
    description: "Base de alta cobertura",
    base_price: 65.90,
    sku: "CF009",
    category: created_categories[3]
  },
  {
    name: "Batom Matte",
    description: "Batom de longa duração",
    base_price: 29.90,
    sku: "CF010",
    category: created_categories[3]
  },
  {
    name: "Perfume Floral",
    description: "Fragrância floral feminina",
    base_price: 120.00,
    sku: "CF011",
    category: created_categories[4]
  },
  {
    name: "Perfume Amadeirado",
    description: "Fragrância amadeirada masculina",
    base_price: 130.00,
    sku: "CF012",
    category: created_categories[4]
  }
]

created_products = produtos.map do |prod_data|
  Product.create!(prod_data.merge(active: true))
end

# Atualizar estoque
puts "Atualizando estoque..."
created_products.each do |product|
  stock_item = product.stock_item
  stock_item.update(quantity: rand(5..50))
end

# Criar clientes
puts "Criando clientes..."
created_representatives.each do |rep|
  5.times do |i|
    Customer.create!(
      name: Faker::Name.name,
      email: Faker::Internet.email,
      phone: Faker::PhoneNumber.cell_phone,
      address: Faker::Address.full_address,
      document: Faker::IDNumber.brazilian_citizen_number(formatted: true),
      representative: rep,
      active: true
    )
  end
end

# Criar pedidos
puts "Criando pedidos..."
statuses = [:pending, :approved, :shipped, :delivered]

Customer.all.each do |customer|
  rand(1..3).times do
    order = Order.new(
      representative: customer.representative,
      customer: customer,
      status: statuses.sample,
      ordered_at: rand(1..60).days.ago
    )
    
    # Adicionar itens ao pedido
    rand(1..5).times do
      product = created_products.sample
      order.order_items.build(
        product: product,
        quantity: rand(1..5),
        unit_price: product.final_price(customer.representative)
      )
    end
    
    order.save!
    
    # Atualizar data da última compra do cliente
    if order.status == "delivered"
      customer.update(last_purchase_at: order.ordered_at)
    end
  end
end

puts "Seed concluído com sucesso!"
