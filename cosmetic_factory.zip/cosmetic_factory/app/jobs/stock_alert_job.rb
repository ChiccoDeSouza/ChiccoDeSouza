# app/jobs/stock_alert_job.rb
class StockAlertJob < ApplicationJob
  queue_as :default

  def perform(stock_item_id)
    stock_item = StockItem.find_by(id: stock_item_id)
    return unless stock_item
    
    product = stock_item.product
    
    # Não notificar novamente se já foi notificado recentemente
    return if stock_item.last_notification_at && stock_item.last_notification_at > 24.hours.ago
    
    # Enviar email para todos os administradores
    User.where(role: :admin).find_each do |admin|
      AdminMailer.stock_alert(admin, product, stock_item).deliver_later
    end
    
    # Atualizar timestamp da última notificação
    stock_item.update(last_notification_at: Time.current)
  end
end
