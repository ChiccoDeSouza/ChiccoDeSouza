# app/jobs/inactive_customer_job.rb
class InactiveCustomerJob < ApplicationJob
  queue_as :default

  def perform
    # Encontrar clientes que não fizeram compras nos últimos 3 meses
    inactive_customers = Customer.where('last_purchase_at < ? OR last_purchase_at IS NULL', 3.months.ago)
    
    inactive_customers.find_each do |customer|
      # Enviar email para o representante sobre o cliente inativo
      RepresentativeMailer.inactive_customer_notification(customer).deliver_later
    end
  end
end
