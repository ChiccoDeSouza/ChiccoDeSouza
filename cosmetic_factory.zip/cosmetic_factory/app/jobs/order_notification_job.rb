# app/jobs/order_notification_job.rb
class OrderNotificationJob < ApplicationJob
  queue_as :default

  def perform(order_id)
    order = Order.find_by(id: order_id)
    return unless order
    
    # Notificar representante
    OrderMailer.new_order_confirmation(order).deliver_later
    
    # Notificar cliente
    OrderMailer.customer_order_confirmation(order).deliver_later
    
    # Notificar administradores
    User.where(role: :admin).find_each do |admin|
      AdminMailer.new_order_notification(admin, order).deliver_later
    end
    
    # Atualizar data da última compra do cliente
    order.customer.update(last_purchase_at: Time.current)
  end
end
