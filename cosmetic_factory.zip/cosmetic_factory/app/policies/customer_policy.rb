# app/policies/customer_policy.rb
class CustomerPolicy < ApplicationPolicy
  def index?
    true
  end

  def show?
    user.admin? || record.representative_id == user.id
  end

  def create?
    user.admin? || user.representative?
  end

  def update?
    user.admin? || record.representative_id == user.id
  end

  def destroy?
    (user.admin? || record.representative_id == user.id) && !record.orders.exists?
  end

  class Scope < Scope
    def resolve
      if user.admin?
        scope.all
      else
        scope.where(representative_id: user.id)
      end
    end
  end
end
