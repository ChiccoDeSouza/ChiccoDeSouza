# app/policies/order_policy.rb
class OrderPolicy < ApplicationPolicy
  def index?
    true
  end

  def show?
    user.admin? || record.representative_id == user.id
  end

  def create?
    user.representative?
  end

  def update?
    user.representative? && record.representative_id == user.id && record.pending?
  end

  def destroy?
    user.representative? && record.representative_id == user.id && record.pending?
  end

  def cancel?
    (user.representative? && record.representative_id == user.id && record.can_cancel?) ||
    (user.admin? && record.can_cancel?)
  end

  def update_status?
    user.admin?
  end

  class Scope < Scope
    def resolve
      if user.admin?
        scope.all
      else
        scope.where(representative_id: user.id)
      end
    end
  end
end
