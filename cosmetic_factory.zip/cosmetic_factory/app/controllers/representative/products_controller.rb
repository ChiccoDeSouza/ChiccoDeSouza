# app/controllers/representative/products_controller.rb
class Representative::ProductsController < Representative::BaseController
  def index
    @products = Product.active
                      .includes(:category, :stock_item)
                      .order(:name)
                      .page(params[:page])
    
    @products = @products.by_category(params[:category_id]) if params[:category_id].present?
    
    if params[:query].present?
      @products = @products.where("name ILIKE ? OR description ILIKE ?", 
                                 "%#{params[:query]}%", 
                                 "%#{params[:query]}%")
    end
  end
  
  def show
    @product = Product.active.find(params[:id])
    @final_price = @product.final_price(current_user)
    @stock_available = @product.in_stock?
  end
end
