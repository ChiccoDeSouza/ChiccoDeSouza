# app/controllers/representative/customers_controller.rb
class Representative::CustomersController < Representative::BaseController
  before_action :set_customer, only: [:show, :edit, :update, :destroy]
  
  def index
    @customers = current_user.customers
                            .order(created_at: :desc)
                            .page(params[:page])
    
    @customers = @customers.where(active: true) if params[:active].present?
  end
  
  def show
    @orders = @customer.orders.where(representative: current_user)
                      .order(created_at: :desc)
                      .limit(10)
  end
  
  def new
    @customer = current_user.customers.build
  end
  
  def create
    @customer = current_user.customers.build(customer_params)
    
    if @customer.save
      redirect_to representative_customer_path(@customer), notice: 'Cliente criado com sucesso.'
    else
      render :new, status: :unprocessable_entity
    end
  end
  
  def edit
  end
  
  def update
    if @customer.update(customer_params)
      redirect_to representative_customer_path(@customer), notice: 'Cliente atualizado com sucesso.'
    else
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    if @customer.destroy
      redirect_to representative_customers_path, notice: 'Cliente excluído com sucesso.'
    else
      redirect_to representative_customer_path(@customer), alert: 'Não foi possível excluir o cliente.'
    end
  end
  
  private
  
  def set_customer
    @customer = current_user.customers.find(params[:id])
  end
  
  def customer_params
    params.require(:customer).permit(
      :name, :email, :phone, :address, :document, :active
    )
  end
end
