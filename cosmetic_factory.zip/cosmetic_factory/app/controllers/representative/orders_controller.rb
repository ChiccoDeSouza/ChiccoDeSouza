# app/controllers/representative/orders_controller.rb
class Representative::OrdersController < Representative::BaseController
  before_action :set_order, only: [:show, :edit, :update, :destroy, :cancel]
  
  def index
    @orders = current_user.orders.includes(:customer)
                         .order(created_at: :desc)
                         .page(params[:page])
    
    @orders = @orders.by_customer(params[:customer_id]) if params[:customer_id].present?
    @orders = @orders.where(status: params[:status]) if params[:status].present?
  end
  
  def show
    @order_items = @order.order_items.includes(:product)
  end
  
  def new
    @order = current_user.orders.build
    @order.order_items.build
    @customers = current_user.customers.active
  end
  
  def create
    @order = current_user.orders.build(order_params)
    @order.ordered_at = Time.current
    
    if @order.save
      redirect_to representative_order_path(@order), notice: 'Pedido criado com sucesso.'
    else
      @customers = current_user.customers.active
      render :new, status: :unprocessable_entity
    end
  end
  
  def edit
    redirect_to representative_order_path(@order), alert: 'Pedidos não podem ser editados após criação.' unless @order.pending?
    @customers = current_user.customers.active
  end
  
  def update
    if @order.pending? && @order.update(order_params)
      redirect_to representative_order_path(@order), notice: 'Pedido atualizado com sucesso.'
    else
      @customers = current_user.customers.active
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    if @order.pending? && @order.destroy
      redirect_to representative_orders_path, notice: 'Pedido excluído com sucesso.'
    else
      redirect_to representative_order_path(@order), alert: 'Apenas pedidos pendentes podem ser excluídos.'
    end
  end
  
  def cancel
    if @order.cancel!
      redirect_to representative_order_path(@order), notice: 'Pedido cancelado com sucesso.'
    else
      redirect_to representative_order_path(@order), alert: 'Não foi possível cancelar o pedido.'
    end
  end
  
  private
  
  def set_order
    @order = current_user.orders.find(params[:id])
  end
  
  def order_params
    params.require(:order).permit(
      :customer_id, :notes,
      order_items_attributes: [:id, :product_id, :quantity, :_destroy]
    )
  end
end
