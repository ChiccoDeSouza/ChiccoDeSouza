# app/controllers/representative/dashboard_controller.rb
class Representative::DashboardController < Representative::BaseController
  def index
    @total_orders = current_user.orders.count
    @pending_orders = current_user.orders.pending.count
    @total_customers = current_user.customers.count
    @inactive_customers = current_user.inactive_customers.count
    
    @recent_orders = current_user.orders
                                .includes(:customer)
                                .order(created_at: :desc)
                                .limit(5)
    
    @top_customers = current_user.customers
                               .joins(:orders)
                               .select('customers.*, COUNT(orders.id) as orders_count')
                               .group('customers.id')
                               .order('orders_count DESC')
                               .limit(5)
    
    @sales_this_month = current_user.sales_this_month
    @sales_last_month = current_user.sales_last_month
    @sales_growth = current_user.sales_growth_percentage
  end
end
