# app/controllers/representative/base_controller.rb
class Representative::BaseController < ApplicationController
  layout 'representative'
  
  before_action :require_representative
  
  private
  
  def require_representative
    unless current_user&.representative?
      flash[:alert] = "Acesso restrito a representantes."
      redirect_to root_path
    end
  end
end
