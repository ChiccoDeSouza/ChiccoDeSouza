# app/controllers/admin/categories_controller.rb
class Admin::CategoriesController < Admin::BaseController
  before_action :set_category, only: [:show, :edit, :update, :destroy]
  
  def index
    @categories = Category.includes(:products)
                         .order(:name)
                         .page(params[:page])
  end
  
  def show
    @products = @category.products.order(:name).page(params[:page])
  end
  
  def new
    @category = Category.new
  end
  
  def create
    @category = Category.new(category_params)
    
    if @category.save
      redirect_to admin_category_path(@category), notice: 'Categoria criada com sucesso.'
    else
      render :new, status: :unprocessable_entity
    end
  end
  
  def edit
  end
  
  def update
    if @category.update(category_params)
      redirect_to admin_category_path(@category), notice: 'Categoria atualizada com sucesso.'
    else
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    if @category.destroy
      redirect_to admin_categories_path, notice: 'Categoria excluída com sucesso.'
    else
      redirect_to admin_category_path(@category), alert: 'Não foi possível excluir a categoria.'
    end
  end
  
  private
  
  def set_category
    @category = Category.find(params[:id])
  end
  
  def category_params
    params.require(:category).permit(:name, :description, :active)
  end
end
