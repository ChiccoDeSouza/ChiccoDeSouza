# app/controllers/admin/customers_controller.rb
class Admin::CustomersController < Admin::BaseController
  before_action :set_customer, only: [:show, :edit, :update, :destroy]
  
  def index
    @customers = Customer.includes(:representative)
                        .order(created_at: :desc)
                        .page(params[:page])
    
    @customers = @customers.where(representative_id: params[:representative_id]) if params[:representative_id].present?
    @customers = @customers.where(active: true) if params[:active].present?
  end
  
  def show
    @orders = @customer.orders.recent.limit(10)
  end
  
  def new
    @customer = Customer.new
    @representatives = Representative.active.order(:name)
  end
  
  def create
    @customer = Customer.new(customer_params)
    
    if @customer.save
      redirect_to admin_customer_path(@customer), notice: 'Cliente criado com sucesso.'
    else
      @representatives = Representative.active.order(:name)
      render :new, status: :unprocessable_entity
    end
  end
  
  def edit
    @representatives = Representative.active.order(:name)
  end
  
  def update
    if @customer.update(customer_params)
      redirect_to admin_customer_path(@customer), notice: 'Cliente atualizado com sucesso.'
    else
      @representatives = Representative.active.order(:name)
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    if @customer.destroy
      redirect_to admin_customers_path, notice: 'Cliente excluído com sucesso.'
    else
      redirect_to admin_customer_path(@customer), alert: 'Não foi possível excluir o cliente.'
    end
  end
  
  def inactive
    @customers = Customer.inactive.includes(:representative).order(updated_at: :desc).page(params[:page])
  end
  
  private
  
  def set_customer
    @customer = Customer.find(params[:id])
  end
  
  def customer_params
    params.require(:customer).permit(
      :name, :email, :phone, :address, :document, 
      :representative_id, :active
    )
  end
end
