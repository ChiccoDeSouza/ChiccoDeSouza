# app/controllers/admin/orders_controller.rb
class Admin::OrdersController < Admin::BaseController
  before_action :set_order, only: [:show, :edit, :update, :destroy, :update_status]
  
  def index
    @orders = Order.includes(:representative, :customer)
                  .order(created_at: :desc)
                  .page(params[:page])
    
    @orders = @orders.by_representative(params[:representative_id]) if params[:representative_id].present?
    @orders = @orders.by_customer(params[:customer_id]) if params[:customer_id].present?
    @orders = @orders.where(status: params[:status]) if params[:status].present?
  end
  
  def show
    @order_items = @order.order_items.includes(:product)
  end
  
  def update_status
    if @order.update(order_status_params)
      redirect_to admin_order_path(@order), notice: 'Status do pedido atualizado com sucesso.'
    else
      redirect_to admin_order_path(@order), alert: 'Não foi possível atualizar o status do pedido.'
    end
  end
  
  def destroy
    if @order.destroy
      redirect_to admin_orders_path, notice: 'Pedido excluído com sucesso.'
    else
      redirect_to admin_order_path(@order), alert: 'Não foi possível excluir o pedido.'
    end
  end
  
  private
  
  def set_order
    @order = Order.find(params[:id])
  end
  
  def order_status_params
    params.require(:order).permit(:status)
  end
end
