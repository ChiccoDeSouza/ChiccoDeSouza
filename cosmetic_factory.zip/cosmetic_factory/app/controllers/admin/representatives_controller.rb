# app/controllers/admin/representatives_controller.rb
class Admin::RepresentativesController < Admin::BaseController
  before_action :set_representative, only: [:show, :edit, :update, :destroy]
  
  def index
    @representatives = Representative.order(:name).page(params[:page])
  end
  
  def show
    @orders = @representative.orders.recent.limit(10)
    @customers = @representative.customers.recent.limit(10)
  end
  
  def new
    @representative = Representative.new
  end
  
  def create
    @representative = Representative.new(representative_params)
    
    if @representative.save
      redirect_to admin_representative_path(@representative), notice: 'Representante criado com sucesso.'
    else
      render :new, status: :unprocessable_entity
    end
  end
  
  def edit
  end
  
  def update
    if @representative.update(representative_params)
      redirect_to admin_representative_path(@representative), notice: 'Representante atualizado com sucesso.'
    else
      render :edit, status: :unprocessable_entity
    end
  end
  
  def destroy
    if @representative.destroy
      redirect_to admin_representatives_path, notice: 'Representante excluído com sucesso.'
    else
      redirect_to admin_representative_path(@representative), alert: 'Não foi possível excluir o representante.'
    end
  end
  
  private
  
  def set_representative
    @representative = Representative.find(params[:id])
  end
  
  def representative_params
    params.require(:representative).permit(
      :name, :email, :password, :password_confirmation, 
      :margin_percentage, :region, :commission_rate, 
      :phone, :document, :active
    )
  end
end
