# app/controllers/admin/dashboard_controller.rb
class Admin::DashboardController < Admin::BaseController
  def index
    @total_orders = Order.count
    @pending_orders = Order.pending.count
    @total_products = Product.count
    @low_stock_items = StockItem.low_stock.count
    @total_representatives = Representative.count
    @total_customers = Customer.count
    
    @recent_orders = Order.includes(:representative, :customer)
                         .order(created_at: :desc)
                         .limit(5)
    
    @top_representatives = Representative.joins(:orders)
                                        .select('users.*, COUNT(orders.id) as orders_count')
                                        .group('users.id')
                                        .order('orders_count DESC')
                                        .limit(5)
    
    @top_products = Product.joins(:order_items)
                          .select('products.*, SUM(order_items.quantity) as total_sold')
                          .group('products.id')
                          .order('total_sold DESC')
                          .limit(5)
  end
end
