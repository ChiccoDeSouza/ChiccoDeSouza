# app/controllers/admin/reports_controller.rb
class Admin::ReportsController < Admin::BaseController
  def index
  end
  
  def sales
    @start_date = params[:start_date] ? Date.parse(params[:start_date]) : 1.month.ago.to_date
    @end_date = params[:end_date] ? Date.parse(params[:end_date]) : Date.today
    
    @orders = Order.where(ordered_at: @start_date.beginning_of_day..@end_date.end_of_day)
                  .where(status: [:approved, :shipped, :delivered])
    
    @total_sales = @orders.sum(:total_amount)
    @order_count = @orders.count
    @average_order_value = @order_count > 0 ? @total_sales / @order_count : 0
    
    @sales_by_day = @orders.group_by_day(:ordered_at, range: @start_date..@end_date)
                          .sum(:total_amount)
    
    @sales_by_representative = @orders.joins(:representative)
                                     .group('users.name')
                                     .sum(:total_amount)
                                     .sort_by { |_, v| -v }
    
    @sales_by_category = OrderItem.joins(product: :category, order: {})
                                 .where(orders: { ordered_at: @start_date.beginning_of_day..@end_date.end_of_day, 
                                                 status: [:approved, :shipped, :delivered] })
                                 .group('categories.name')
                                 .sum('order_items.final_price')
                                 .sort_by { |_, v| -v }
  end
  
  def inventory
    @low_stock_items = StockItem.low_stock.includes(:product)
    @out_of_stock_items = StockItem.out_of_stock.includes(:product)
    @stock_value = StockItem.joins(:product).sum('stock_items.quantity * products.base_price')
    
    @stock_by_category = StockItem.joins(product: :category)
                                 .group('categories.name')
                                 .sum('stock_items.quantity')
                                 .sort_by { |_, v| -v }
  end
  
  def representatives_performance
    @start_date = params[:start_date] ? Date.parse(params[:start_date]) : 3.months.ago.to_date
    @end_date = params[:end_date] ? Date.parse(params[:end_date]) : Date.today
    
    @representatives = Representative.all
    
    @sales_data = {}
    @order_counts = {}
    @customer_counts = {}
    
    @representatives.each do |rep|
      @sales_data[rep.name] = rep.orders
                                .where(ordered_at: @start_date.beginning_of_day..@end_date.end_of_day)
                                .where(status: [:approved, :shipped, :delivered])
                                .sum(:total_amount)
      
      @order_counts[rep.name] = rep.orders
                                  .where(ordered_at: @start_date.beginning_of_day..@end_date.end_of_day)
                                  .count
      
      @customer_counts[rep.name] = rep.customers.count
    end
    
    @sales_data = @sales_data.sort_by { |_, v| -v }.to_h
    @order_counts = @order_counts.sort_by { |_, v| -v }.to_h
  end
end
