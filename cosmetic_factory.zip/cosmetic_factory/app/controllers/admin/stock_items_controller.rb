# app/controllers/admin/stock_items_controller.rb
class Admin::StockItemsController < Admin::BaseController
  before_action :set_stock_item, only: [:show, :edit, :update]
  
  def index
    @stock_items = StockItem.includes(:product)
                           .order('products.name')
                           .page(params[:page])
  end
  
  def show
  end
  
  def edit
  end
  
  def update
    if @stock_item.update(stock_item_params)
      redirect_to admin_stock_item_path(@stock_item), notice: 'Estoque atualizado com sucesso.'
    else
      render :edit, status: :unprocessable_entity
    end
  end
  
  def low_stock
    @stock_items = StockItem.low_stock
                           .includes(:product)
                           .order('products.name')
                           .page(params[:page])
  end
  
  private
  
  def set_stock_item
    @stock_item = StockItem.find(params[:id])
  end
  
  def stock_item_params
    params.require(:stock_item).permit(:quantity, :minimum_quantity)
  end
end
