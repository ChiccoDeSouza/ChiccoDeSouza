# app/models/order.rb
class Order < ApplicationRecord
  # Associations
  belongs_to :representative
  belongs_to :customer
  has_many :order_items, dependent: :destroy
  has_many :products, through: :order_items

  # Enums
  enum status: {
    pending: 0,
    approved: 1,
    shipped: 2,
    delivered: 3,
    canceled: 4
  }

  # Validations
  validates :status, presence: true
  validate :must_have_items

  # Callbacks
  before_save :calculate_total
  after_create :send_notification
  after_update :notify_status_change, if: :saved_change_to_status?

  # Scopes
  scope :recent, -> { order(created_at: :desc) }
  scope :completed, -> { where(status: [:delivered]) }
  scope :in_progress, -> { where(status: [:pending, :approved, :shipped]) }
  scope :by_representative, ->(representative_id) { where(representative_id: representative_id) }
  scope :by_customer, ->(customer_id) { where(customer_id: customer_id) }
  scope :by_date_range, ->(start_date, end_date) { where(ordered_at: start_date..end_date) }

  # Methods
  def total_items
    order_items.sum(:quantity)
  end

  def can_cancel?
    pending? || approved?
  end

  def cancel!
    return false unless can_cancel?
    
    transaction do
      update!(status: :canceled)
      order_items.each do |item|
        # Retorna os itens ao estoque se o pedido já estava aprovado
        if approved?
          stock_item = item.product.stock_item
          stock_item.update!(quantity: stock_item.quantity + item.quantity)
        end
      end
    end
    true
  end

  private

  def calculate_total
    self.total_amount = order_items.sum { |item| item.final_price }
  end

  def send_notification
    OrderNotificationJob.perform_later(id)
  end

  def notify_status_change
    OrderMailer.status_updated(self).deliver_later
  end

  def must_have_items
    errors.add(:base, "Order must have at least one item") if order_items.empty?
  end
end
