# app/models/user.rb
class User < ApplicationRecord
  # Devise modules
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable,
         :trackable, :lockable, :timeoutable

  # Enums
  enum role: { representative: 0, admin: 1 }

  # Validations
  validates :name, presence: true
  validates :email, presence: true, uniqueness: true

  # Callbacks
  before_create :set_default_role

  # Scopes
  scope :active, -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :recent, -> { order(created_at: :desc) }

  # Methods
  def admin?
    role == 'admin'
  end

  def representative?
    role == 'representative'
  end

  def active_for_authentication?
    super && active?
  end

  def inactive_message
    active? ? super : :account_inactive
  end

  private

  def set_default_role
    self.role ||= :representative
  end
end
