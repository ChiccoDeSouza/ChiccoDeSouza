# app/models/stock_item.rb
class StockItem < ApplicationRecord
  # Associations
  belongs_to :product

  # Validations
  validates :quantity, presence: true, numericality: { greater_than_or_equal_to: 0 }
  validates :minimum_quantity, presence: true, numericality: { greater_than: 0 }

  # Scopes
  scope :low_stock, -> { where('quantity < minimum_quantity') }
  scope :out_of_stock, -> { where(quantity: 0) }
  scope :needs_restock, -> { where('quantity < minimum_quantity * 0.5') }

  # Callbacks
  after_save :check_stock_level

  # Methods
  def stock_below_threshold?
    quantity < minimum_quantity
  end

  def percentage_remaining
    (quantity.to_f / minimum_quantity) * 100
  end

  def needs_restock?
    quantity < (minimum_quantity * 0.5)
  end

  private

  def check_stock_level
    if quantity < (minimum_quantity * 0.2)
      StockAlertJob.perform_later(id)
    end
  end
end
