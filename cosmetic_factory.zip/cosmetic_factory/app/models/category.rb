# app/models/category.rb
class Category < ApplicationRecord
  # Associations
  has_many :products, dependent: :restrict_with_error

  # Validations
  validates :name, presence: true, uniqueness: true

  # Scopes
  scope :active, -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :with_products, -> { joins(:products).distinct }
  scope :ordered, -> { order(:name) }

  # Methods
  def product_count
    products.count
  end

  def active_product_count
    products.active.count
  end
end
