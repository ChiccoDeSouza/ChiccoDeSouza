# app/models/customer.rb
class Customer < ApplicationRecord
  include Encryptable
  
  # Associations
  belongs_to :representative
  has_many :orders, dependent: :nullify

  # Validations
  validates :name, presence: true
  validates :email, presence: true, uniqueness: true
  validates :document, presence: true, uniqueness: true

  # Encrypted attributes
  encrypts :email
  encrypts :phone
  encrypts :address
  encrypts :document

  # Blind indexes for searching encrypted fields
  blind_index :email
  blind_index :document

  # Scopes
  scope :active, -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :recent, -> { order(created_at: :desc) }
  scope :without_purchases, -> { where(last_purchase_at: nil) }
  scope :with_recent_purchases, -> { where('last_purchase_at > ?', 3.months.ago) }

  # Callbacks
  after_create :send_welcome_email

  # Methods
  def inactive?
    !active? || (last_purchase_at.present? && last_purchase_at < 3.months.ago)
  end

  def total_spent
    orders.completed.sum(:total_amount)
  end

  def average_order_value
    completed_orders = orders.completed
    return 0 if completed_orders.empty?
    completed_orders.sum(:total_amount) / completed_orders.count
  end

  private

  def send_welcome_email
    CustomerMailer.welcome(self).deliver_later
  end
end
