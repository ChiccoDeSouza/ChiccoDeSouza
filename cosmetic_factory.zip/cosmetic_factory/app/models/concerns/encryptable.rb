# app/models/concerns/encryptable.rb
module Encryptable
  extend ActiveSupport::Concern

  class_methods do
    def blind_index(attribute)
      # Este método seria implementado com a gem blind_index em um ambiente real
      # Para este exemplo, estamos apenas definindo o método para demonstrar a estrutura
    end
  end
end
