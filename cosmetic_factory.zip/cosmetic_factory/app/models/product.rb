# app/models/product.rb
class Product < ApplicationRecord
  # Associations
  belongs_to :category
  has_many :order_items, dependent: :restrict_with_error
  has_one :stock_item, dependent: :destroy
  has_one_attached :image

  # Validations
  validates :name, presence: true
  validates :base_price, presence: true, numericality: { greater_than: 0 }
  validates :sku, presence: true, uniqueness: true
  validates :image, content_type: ['image/png', 'image/jpeg', 'image/jpg'],
                   size: { less_than: 5.megabytes }, allow_nil: true

  # Callbacks
  after_create :create_stock_item
  after_save :update_order_items_price, if: :saved_change_to_base_price?

  # Scopes
  scope :active, -> { where(active: true) }
  scope :inactive, -> { where(active: false) }
  scope :by_category, ->(category_id) { where(category_id: category_id) }
  scope :low_stock, -> { joins(:stock_item).where('stock_items.quantity < stock_items.minimum_quantity') }
  scope :in_stock, -> { joins(:stock_item).where('stock_items.quantity > 0') }
  scope :out_of_stock, -> { joins(:stock_item).where('stock_items.quantity <= 0') }

  # Methods
  def final_price(representative)
    base_price * (1 + representative.margin_percentage/100.0)
  end

  def in_stock?
    stock_item.present? && stock_item.quantity.positive?
  end

  def low_stock?
    stock_item.present? && stock_item.quantity < stock_item.minimum_quantity
  end

  def stock_level
    stock_item&.quantity || 0
  end

  private

  def create_stock_item
    build_stock_item(quantity: 0, minimum_quantity: 10).save
  end

  def update_order_items_price
    # Atualiza apenas itens de pedidos pendentes
    pending_items = order_items.joins(:order).where(orders: { status: 'pending' })
    pending_items.find_each do |item|
      representative = item.order.representative
      item.update(unit_price: final_price(representative))
    end
  end
end
