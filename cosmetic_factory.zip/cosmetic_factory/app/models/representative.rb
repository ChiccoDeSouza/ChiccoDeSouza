# app/models/representative.rb
class Representative < User
  # Validations
  validates :margin_percentage, presence: true, numericality: { greater_than_or_equal_to: 0 }
  validates :region, presence: true
  validates :commission_rate, presence: true, numericality: { greater_than_or_equal_to: 0 }

  # Associations
  has_many :customers, dependent: :nullify
  has_many :orders, dependent: :nullify

  # Encrypted attributes
  encrypts :phone
  encrypts :document

  # Scopes
  scope :by_region, ->(region) { where(region: region) }
  scope :by_performance, -> { joins(:orders).group(:id).order('COUNT(orders.id) DESC') }

  # Methods
  def inactive_customers
    customers.where('last_purchase_at < ?', 3.months.ago)
  end

  def total_sales(period = nil)
    scope = orders.completed
    scope = scope.where('ordered_at >= ?', period) if period
    scope.sum(:total_amount)
  end

  def sales_this_month
    total_sales(Time.current.beginning_of_month)
  end

  def sales_last_month
    total_sales(1.month.ago.beginning_of_month..1.month.ago.end_of_month)
  end

  def sales_growth_percentage
    return 0 if sales_last_month.zero?
    ((sales_this_month - sales_last_month) / sales_last_month) * 100
  end
end
