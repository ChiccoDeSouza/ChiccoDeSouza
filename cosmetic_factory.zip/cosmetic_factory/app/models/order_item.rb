# app/models/order_item.rb
class OrderItem < ApplicationRecord
  # Associations
  belongs_to :order
  belongs_to :product

  # Validations
  validates :quantity, presence: true, numericality: { greater_than: 0 }
  validates :unit_price, presence: true, numericality: { greater_than: 0 }
  validates :product_id, uniqueness: { scope: :order_id, message: "já foi adicionado a este pedido" }

  # Callbacks
  before_save :calculate_final_price
  after_save :update_order_total
  after_destroy :update_order_total

  # Methods
  def calculate_final_price
    self.final_price = quantity * unit_price
  end

  private

  def update_order_total
    order.save # Isso acionará o callback calculate_total no modelo Order
  end
end
