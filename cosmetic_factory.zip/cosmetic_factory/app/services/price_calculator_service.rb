# app/services/price_calculator_service.rb
class PriceCalculatorService
  def initialize(product, representative)
    @product = product
    @representative = representative
  end

  def calculate
    base_price = @product.base_price
    margin_percentage = @representative.margin_percentage
    
    # Cálculo básico com margem do representante
    price = base_price * (1 + margin_percentage/100.0)
    
    # Aplicar regras adicionais se necessário
    apply_volume_discount(price)
  end

  private

  def apply_volume_discount(price)
    # Exemplo de regra de desconto baseada no volume de vendas do representante
    sales_volume = @representative.total_sales(1.month.ago)
    
    if sales_volume > 50000
      price * 0.95  # 5% de desconto para representantes com alto volume
    elsif sales_volume > 20000
      price * 0.98  # 2% de desconto para representantes com volume médio
    else
      price  # Sem desconto
    end
  end
end
