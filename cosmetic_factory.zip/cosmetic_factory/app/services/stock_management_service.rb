# app/services/stock_management_service.rb
class StockManagementService
  def initialize(product)
    @product = product
    @stock_item = product.stock_item
  end

  def update_stock(quantity_change)
    return false unless @stock_item

    new_quantity = @stock_item.quantity + quantity_change
    
    if new_quantity < 0
      return false # Não permitir estoque negativo
    end
    
    @stock_item.update(
      quantity: new_quantity,
      last_restock_at: (quantity_change.positive? ? Time.current : @stock_item.last_restock_at)
    )
  end

  def check_low_stock
    return false unless @stock_item
    
    if @stock_item.stock_below_threshold? && !recently_notified?
      StockAlertJob.perform_later(@stock_item.id)
      true
    else
      false
    end
  end

  private

  def recently_notified?
    @stock_item.last_notification_at.present? && 
    @stock_item.last_notification_at > 24.hours.ago
  end
end
