# app/services/data_export_service.rb
class DataExportService
  def initialize(customer)
    @customer = customer
  end

  def generate_personal_data
    {
      name: @customer.name,
      email: @customer.email,
      phone: @customer.phone,
      address: @customer.address,
      document: @customer.document,
      created_at: @customer.created_at,
      last_purchase_at: @customer.last_purchase_at,
      orders: order_data
    }
  end

  private

  def order_data
    @customer.orders.map do |order|
      {
        id: order.id,
        ordered_at: order.ordered_at,
        status: order.status,
        total_amount: order.total_amount,
        items: order_items_data(order)
      }
    end
  end

  def order_items_data(order)
    order.order_items.map do |item|
      {
        product_name: item.product.name,
        quantity: item.quantity,
        unit_price: item.unit_price,
        final_price: item.final_price
      }
    end
  end
end
