# app/mailers/admin_mailer.rb
class AdminMailer < ApplicationMailer
  def new_order_notification(admin, order)
    @admin = admin
    @order = order
    @representative = order.representative
    @customer = order.customer
    @order_items = order.order_items.includes(:product)
    
    mail(
      to: @admin.email,
      subject: "Novo pedido ##{@order.id} criado por #{@representative.name}"
    )
  end
  
  def stock_alert(admin, product, stock_item)
    @admin = admin
    @product = product
    @stock_item = stock_item
    @percentage = @stock_item.percentage_remaining.round(2)
    
    mail(
      to: @admin.email,
      subject: "ALERTA: Estoque baixo para #{@product.name}"
    )
  end
end
