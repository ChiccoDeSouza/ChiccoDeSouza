# app/mailers/order_mailer.rb
class OrderMailer < ApplicationMailer
  def new_order_confirmation(order)
    @order = order
    @representative = order.representative
    @customer = order.customer
    @order_items = order.order_items.includes(:product)
    
    mail(
      to: @representative.email,
      subject: "Novo pedido ##{@order.id} criado com sucesso"
    )
  end
  
  def customer_order_confirmation(order)
    @order = order
    @representative = order.representative
    @customer = order.customer
    @order_items = order.order_items.includes(:product)
    
    mail(
      to: @customer.email,
      subject: "Seu pedido ##{@order.id} foi recebido"
    )
  end
  
  def status_updated(order)
    @order = order
    @representative = order.representative
    @customer = order.customer
    
    mail(
      to: @customer.email,
      cc: @representative.email,
      subject: "Atualização do pedido ##{@order.id}: #{@order.status.humanize}"
    )
  end
end
