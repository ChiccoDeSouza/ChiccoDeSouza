# app/mailers/customer_mailer.rb
class CustomerMailer < ApplicationMailer
  def welcome(customer)
    @customer = customer
    @representative = customer.representative
    
    mail(
      to: @customer.email,
      subject: "Bem-vindo à Cosmetic Factory!"
    )
  end
end
