# app/mailers/representative_mailer.rb
class RepresentativeMailer < ApplicationMailer
  def inactive_customer_notification(customer)
    @customer = customer
    @representative = customer.representative
    @last_purchase = @customer.last_purchase_at
    @days_inactive = @last_purchase ? (Date.today - @last_purchase.to_date).to_i : "N/A"
    
    mail(
      to: @representative.email,
      subject: "Cliente inativo: #{@customer.name}"
    )
  end
end
